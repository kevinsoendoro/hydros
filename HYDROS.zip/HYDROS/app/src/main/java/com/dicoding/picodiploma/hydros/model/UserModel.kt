package com.dicoding.picodiploma.hydros.model

data class UserModel(
    val name: String,
    val token: String,
    val isLogin: Boolean
)